RibAV INPUTS: (Data/Defaults)
------------------------------

DefaultSimulationPoints.csv

	Every row corresponds to a specific simulation point. The first row is described bellow:

	Column 1: 1_1_1 = "transect number"_"point number within the transect"_"id number"
	Column 2: 854.703 = Elevation above sea level (meters) of each simulation point
	Column 3: 3 = soil type (the soil types must be defined in the soil parameters file to correspond each point clasification)
	Column 4: 1 = transect number
	Column 5: 6.438 = horizontal distance (meters) from the stream
	Column 6: 1 = "id number"
	Column 7: TV = Observed plant functional type (PFT). In this case is TV (Terrestrial vegetation). In the vegetation parameters files all the PFTs should be defined.
		  The definition of the observed PFT does not influence the simulation result, it is only defined for comparative purposes.
 	Column 8: 1 = Vegetation coverage (between 0 and 1)
	Column 9: Terrestrial vegetation = Observed PFT name (not necessary, it can be filled as column 7)
	Column 10: Oak forest = vegetation description (not necessary, it can be filled as column 7)

Hydromet.csv

	Every row corresponds to a specific day. The first row is described bellow:
	Column 1: 01/01/1983 = Date (DD/MM/aaaa)
	Column 2: 0 = Daily Precipitation (mm)
	Column 3: 0.899850498 = Daily Potential Evapotranspiration (mm)
	Column 4: 1.230261914 = Daily flow (m3/s)

RatingCurves.csv
	
	You can define in rows as much reference points within the rating curves as you can. The model interpolates the available upper and lower reference water table elevations (WTE) to obtain the 
	WTE corresponding to the daily flow value defined in the Hydromet file.

	Column 1: 0 = Flow reference value (m3/s), rating curve for transect 1
	Column 2: 847.71 = WTE (m.a.s.l), rating curve for transect 1
	Column 3: 0 = Flow reference value (m3/s), rating curve for transect 2
	Column 4: 847.64 = WTE (m.a.s.l), rating curve for transect 2
	Column 5: 0 = Flow reference value (m3/s), rating curve for transect 3
	Column 6: 847.68 = WTE (m.a.s.l), rating curve for transect 3
	Column 7: you can add as much transects as you need (Flow;WTE)

SoilParameters.csv

	Every row corresponds to a specific soil type. The first row is described bellow:
	Column 1: 1 = Soil type
	Column 2: 0.397 = Porosity [ ]
	Column 3: 0.530 = Porosity Index [ ]
	Column 4: 3.847 = Bubble Pressure [Kpa]
	Column 5: 56.24 = Soil Saturated Hydraulic Conductivity [mm/hr]
	Column 6: 0.131 = Field Capacity Moisture (Typical value, moisture to 33 Kpa) [ ]
	Column 7: Soil1 = Soil type description
	Column 8: 17 = Soil depth to be considered in the Capillary Water Rise [m]

VegetationParameters.csv

	Every row corresponds to a specific PFT. The first row is described bellow:

	Column 1: 1 = Plant functional type number
	Column 2: RH = Plant functional type name
	Column 3: 1.25 = Maximum Root Depth [m]
	Column 4: 0.7 = Effective Root Depth [m]
	Column 5: -0.9 = Saturation Extinction Depth [m], this value is <0 when the PFT can endure water elevations over the surface elevation
	Column 6: 0.7 = Transpiration Factor from the unsaturated Zone [ ], the value must be between 0 and 1
	Column 6: 0.9 = Transpiration Factor from the saturated Zone [ ], the value must be between 0 and 1
	Column 8: 0.97 = Maximum Soil-Root Water Conductance [mmMpa-1h-1]
	Column 9: 1500 = Permanent Wilting Point Pressure [KPa]
	Column 10: 500 = Critical Moisture Pressure [KPa]
	Columns 11-22: 0.7 = Plant cover for each month (Column 11: January - Column 22: December)

	This parameters should be calibrated if your study site is not located in Mediterranean semiarid environment or if you want to add any other PFTs.



RibAV 1D OUTPUTS (Data/Projects/your project folder)
----------------------------------------------------

	The results are exported to a spreadsheet named Calibration matrix "your proyect name".xls
	
	Column 1: simulation point ID number
	Column 2: observed PFT
	Column 3: ETidx for the PFT number 1
	Column 4: ETidx for the PFT number 2
	Column 5: ETidx for the PFT number 3
	Column 6: ETidx for the PFT number 4

	If you want to know the simulated PFT you only need to find the maximum ETidx for each point. The ETidx shows the real evapotranspiration average rate (referred to the potential evapotranspiration),
	for the simulation time period. The zonation hypothesis assumes that the most favoured PFT is the one with higher ETidx. 

